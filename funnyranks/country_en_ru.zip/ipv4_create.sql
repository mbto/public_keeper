CREATE TABLE `ipv4` (
`start_int` int unsigned NOT NULL,
`last_int` int unsigned NOT NULL,
`v_geoname_id` int unsigned NOT NULL COMMENT 'One of valid geoname_id (from ipblocks_priority_geonameId_groupNames setting)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;