ALTER TABLE `ipv4`
ADD UNIQUE INDEX `ipv4_start_int_UNIQUE` (`start_int`),
ADD UNIQUE INDEX `ipv4_last_int_UNIQUE` (`last_int`),
ADD INDEX `ipv4_v_geoname_id_fk_idx` (`v_geoname_id`),
ADD CONSTRAINT `ipv4_v_geoname_id_fk` FOREIGN KEY (`v_geoname_id`) REFERENCES `country` (`geoname_id`) ON UPDATE CASCADE ON DELETE RESTRICT;